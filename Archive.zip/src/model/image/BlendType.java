package model.image;

/**
 * Enum to keep track of the two blending types when exporting images.
 */
public enum BlendType {
  AVG, ADD
}
